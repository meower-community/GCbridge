# gcbridge
GCBridge lets you talk to people in home from a groupchat. <br>
Why? Because why not.

## Hosting platform/source
https://replit.com/@AXEstudios/gcbridge

Oh, btw, if you want to use someone's bot from a gc for some reason,
but can't, if their bot supports gcbridge you can do it succesfully.

## How to start it:
```
~/gcbridge$ PSWD="password";export PSWD;npm run start
```
You can't use it with the Run command included in the config files